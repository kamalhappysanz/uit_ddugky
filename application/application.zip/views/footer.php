
            <!--// CopyRight \\-->
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="education-copyright">
                            <p>© 2017, All Right Reserved - by <a href="https://happysanztech.com" target="_blank">Happy Sanz Tech</a></p>

                            <a href="#" class="education-back-top"><i class="fa fa-angle-up"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <!--// CopyRight \\-->

        </footer>
        <!--// Footer \\-->



    </div>
    <!--// Main Wrapper \\-->



	<script type="text/javascript" src="<?php echo base_url(); ?>assets/script/jquery.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/script/bootstrap.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/script/slick.slider.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/script/jquery.countdown.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/script/fancybox.pack.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/script/progressbar.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/script/counter.js"></script>
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/script/functions.js"></script>

  </body>
</html>
