		<div class="education-banner">

            <!--// Slider \\-->
            <div class="education-banner-one">
                <div class="education-banner-one-layer">
                    <img src="<?php echo base_url(); ?>assets/extra-images/banner-1.jpg" alt="" style="width:100%;">
                    <div class="education-banner-caption">
                        <span class="education-bgcolor">The Best Learning Institution</span>
                        <br>
                        <span class="education-bgcolor banner-title">Wellcome To Our University</span>
                    </div>

                </div>
                <div class="education-banner-one-layer">
                     <img src="<?php echo base_url(); ?>assets/extra-images/banner-2.jpg" alt="" style="width:100%;">
                    <div class="education-banner-caption">
                        <span class="education-bgcolor">The Best Learning Institution</span>
                        <br>
                        <span class="education-bgcolor banner-title">Wellcome To Our University</span>
                    </div>

                </div>
            </div>
            <!--// Slider \\-->

        </div>
		<!--// Main Banner \\-->

		<!--// Main Content \\-->
		<div class="education-main-content">

			<!--// Main Section \\-->
			<div class="education-main-section">
				<div class="container">
					<div class="row">

                        <!--// Services \\-->
						<div class="col-md-12">
                            <div class="education-fancy-title">
                                <i class="fa fa-graduation-cap"></i>
                                <span>what we provide</span>
                                <h2>Our Services</h2>
                            </div>
                            <div class="education-service education-service-grid">
                                <ul class="row">
                                    <li class="col-md-3">
                                        <div class="education-service-grid-wrap">
                                             <img src="<?php echo base_url(); ?>assets/images/icons/android.png" alt="">
                                            <h5><a href="">Android Developer</a></h5>
                                            <p>Lorem ipsum dolor sit amet, con ctetur adipiscing elit. Praese</p>
                                            <a href="" class="education-readmore-btn">Read More <i class="fa fa-arrow-circle-o-right"></i></a>
                                        </div>
                                    </li>
                                    <li class="col-md-3">
                                        <div class="education-service-grid-wrap">
                                             <img src="<?php echo base_url(); ?>assets/images/icons/auto.png" alt="">
                                            <h5><a href="">Automotive</a></h5>
                                            <p>Lorem ipsum dolor sit amet, con ctetur adipiscing elit. Praese</p>
                                            <a href="" class="education-readmore-btn">Read More <i class="fa fa-arrow-circle-o-right"></i></a>
                                        </div>
                                    </li>
                                    <li class="col-md-3">
                                        <div class="education-service-grid-wrap">
                                             <img src="<?php echo base_url(); ?>assets/images/icons/solar_pv.png" alt="">
                                            <h5><a href="">Solar PV</a></h5>
                                            <p>Lorem ipsum dolor sit amet, con ctetur adipiscing elit. Praese</p>
                                            <a href="" class="education-readmore-btn">Read More <i class="fa fa-arrow-circle-o-right"></i></a>
                                        </div>
                                    </li>
                                    <li class="col-md-3">
                                        <div class="education-service-grid-wrap">
                                             <img src="<?php echo base_url(); ?>assets/images/icons/solar.png" alt="">
                                            <h5><a href="">Solar Installation</a></h5>
                                            <p>Lorem ipsum dolor sit amet, con ctetur adipiscing elit. Praese</p>
                                            <a href="" class="education-readmore-btn">Read More <i class="fa fa-arrow-circle-o-right"></i></a>
                                        </div>
                                    </li>
                                    <li class="col-md-3">
                                        <div class="education-service-grid-wrap">
                                             <img src="<?php echo base_url(); ?>assets/images/icons/repair.png" alt="">
                                            <h5><a href="">Handset Repair Engineer</a></h5>
                                            <p>Lorem ipsum dolor sit amet, con ctetur adipiscing elit. Praese</p>
                                            <a href="" class="education-readmore-btn">Read More <i class="fa fa-arrow-circle-o-right"></i></a>
                                        </div>
                                    </li>
                                    <li class="col-md-3">
                                        <div class="education-service-grid-wrap">
                                            <img src="<?php echo base_url(); ?>assets/images/icons/print.png" alt="">
                                            <h5><a href="">Print Publishing Assistant</a></h5>
                                            <p>Lorem ipsum dolor sit amet, con ctetur adipiscing elit. Praese</p>
                                            <a href="" class="education-readmore-btn">Read More <i class="fa fa-arrow-circle-o-right"></i></a>
                                        </div>
                                    </li>
                                    <li class="col-md-3">
                                        <div class="education-service-grid-wrap">
                                            <img src="<?php echo base_url(); ?>assets/images/icons/electronic.png" alt="">
                                            <h5><a href="">Electronics</a></h5>
                                            <p>Lorem ipsum dolor sit amet, con ctetur adipiscing elit. Praese</p>
                                            <a href="" class="education-readmore-btn">Read More <i class="fa fa-arrow-circle-o-right"></i></a>
                                        </div>
                                    </li>
                                    <li class="col-md-3">
                                        <div class="education-service-grid-wrap">
                                            <img src="<?php echo base_url(); ?>assets/images/icons/cnc.png" alt="">
                                            <h5><a href="">CNC Operator</a></h5>
                                            <p>Lorem ipsum dolor sit amet, con ctetur adipiscing elit. Praese</p>
                                            <a href="" class="education-readmore-btn">Read More <i class="fa fa-arrow-circle-o-right"></i></a>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <!--// Services \\-->

					</div>
				</div>
			</div>
			<!--// Main Section \\-->

            <!--// Main Section \\-->
            <div class="education-main-section education-modren-coursefull">
                <div class="container">
                    <div class="row">

                        <div class="col-md-12">
                            <div class="education-fancy-title">
                                <i class="fa fa-graduation-cap"></i>
                                <span>Choose Your Course</span>
                                <h2>Top Courses</h2>
                            </div>
                            <div class="education-course education-modren-course">
                                <ul class="row">
                                    <li class="col-md-4">
                                        <figure><a href=""><img src="<?php echo base_url(); ?>assets/extra-images/courses-modren-img1.jpg" alt=""> <i class="fa fa-link"></i></a>
                                            <div class="star-rating"><span class="star-rating-box" style="width:55%"></span></div>
                                            <span>$170</span>
                                        </figure>
                                        <div class="education-grid-wrap">
                                            <div class="education-modren-course-text">
                                                <h5><a href="">Coral Fashion Designer</a></h5>
                                                <ul class="education-course-option">
                                                    <li><a href="">By John Ryan</a></li>
                                                    <li>Aug 21st, 2017</li>
                                                </ul>
                                                <p>Lorem ipsum dolor sit amet, conseetur adiis cing elit. Praesent feugiat ur non ipsu mu malesuada. Donec non ex faucibus.</p>
                                            </div>
                                            <div class="education-comment-option">
                                                <figure><img src="extra-images/comment-option-img.jpg" alt=""></figure>
                                                <a href="">Jenny Harris</a>
                                                <ul class="education-comment">
                                                    <li><a href=""><i class="fa fa-comments"></i>21</a></li>
                                                    <li><a href=""><i class="fa fa-eye"></i>12</a></li>
                                                    <li><a href=""><i class="fa fa-share-alt"></i></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="col-md-4">
                                        <figure><a href=""><img src="<?php echo base_url(); ?>assets/extra-images/courses-modren-img2.jpg" alt=""> <i class="fa fa-link"></i></a>
                                            <div class="star-rating"><span class="star-rating-box" style="width:55%"></span></div>
                                            <span>$170</span>
                                        </figure>
                                        <div class="education-grid-wrap">
                                            <div class="education-modren-course-text">
                                                <h5><a href="">Coral Fashion Designer</a></h5>
                                                <ul class="education-course-option">
                                                    <li><a href="">By John Ryan</a></li>
                                                    <li>Aug 21st, 2017</li>
                                                </ul>
                                                <p>Lorem ipsum dolor sit amet, conseetur adiis cing elit. Praesent feugiat ur non ipsu mu malesuada. Donec non ex faucibus.</p>
                                            </div>
                                            <div class="education-comment-option">
                                                <figure><img src="<?php echo base_url(); ?>assets/extra-images/comment-option-img.jpg" alt=""></figure>
                                                <a href="">Jenny Harris</a>
                                                <ul class="education-comment">
                                                    <li><a href=""><i class="fa fa-comments"></i>21</a></li>
                                                    <li><a href=""><i class="fa fa-eye"></i>12</a></li>
                                                    <li><a href=""><i class="fa fa-share-alt"></i></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="col-md-4">
                                        <figure><a href=""><img src="<?php echo base_url(); ?>assets/extra-images/courses-modren-img3.jpg" alt=""> <i class="fa fa-link"></i></a>
                                            <div class="star-rating"><span class="star-rating-box" style="width:55%"></span></div>
                                            <span>$170</span>
                                        </figure>
                                        <div class="education-grid-wrap">
                                            <div class="education-modren-course-text">
                                                <h5><a href="">Coral Fashion Designer</a></h5>
                                                <ul class="education-course-option">
                                                    <li><a href="">By John Ryan</a></li>
                                                    <li>Aug 21st, 2017</li>
                                                </ul>
                                                <p>Lorem ipsum dolor sit amet, conseetur adiis cing elit. Praesent feugiat ur non ipsu mu malesuada. Donec non ex faucibus.</p>
                                            </div>
                                            <div class="education-comment-option">
                                                <figure><img src="<?php echo base_url(); ?>assets/extra-images/comment-option-img.jpg" alt=""></figure>
                                                <a href="">Jenny Harris</a>
                                                <ul class="education-comment">
                                                    <li><a href=""><i class="fa fa-comments"></i>21</a></li>
                                                    <li><a href=""><i class="fa fa-eye"></i>12</a></li>
                                                    <li><a href=""><i class="fa fa-share-alt"></i></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <!--// Main Section \\-->

            <!--// Main Section \\-->
            <div class="education-main-section education-testimonial-full">
                <span class="education-shape-one"></span>
                <span class="education-shape-two"></span>
                <span class="testimonial-transparent"></span>
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="education-testimonial">
                                <i class="fa fa-quote-right"></i>
                                <div class="clearfix"></div>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent feugiat urna non ipsum maximus malesuada. Done c non ex faucibus, fringilla tellus eget, Proin eleifend velit ve maximus arcu.et eros nisl. Morbi faucibus nibh ligula, et cursus nibh elementum vel. </p>
                                <div class="education-testimonial-figure">
                                    <figure><img src="<?php echo base_url(); ?>assets/extra-images/testimonial-fig-img.jpg" alt=""></figure>
                                    <section>
                                        <h6><a href="">Donald Simpson</a></h6>
                                        <span>Founder & SEO</span>
                                    </section>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--// Main Section \\-->

            <!--// Main Section \\-->
            <div class="education-main-section education-letest-newsfull">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="education-latest-news-heading">
                                <span>update About Learn</span>
                                <h2>Latest News</h2>
                            </div>
                            <div class="education-blog education-blog-classic">
                                <div class="latest-news-slider">
                                    <div class="classic-blog-padding">
                                        <figure><a href=""><img src="<?php echo base_url(); ?>assets/extra-images/classic-blog-img1.jpg" alt=""><i class="fa fa-link"></i></a>
                                            <figcaption><img src="extra-images/classic-figcaption-img1.jpg" alt=""></figcaption>
                                        </figure>
                                        <div class="education-blog-classic-text">
                                            <h5><a href="">Variation Of Ordinary Lor</a></h5>
                                            <ul class="education-course-option">
                                                <li><a href="">By John Ryan</a></li>
                                                <li>Aug 21st, 2017</li>
                                            </ul>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipci ng elit. Praesent feugiat urna ipsum maxis malesuada. Donec non ex faucibus,</p>
                                            <a href="" class="education-readmore-btn">Read More <i class="fa fa-long-arrow-right"></i></a>
                                        </div>
                                    </div>
                                    <div class="classic-blog-padding">
                                        <figure><a href=""><img src="<?php echo base_url(); ?>assets/extra-images/classic-blog-img2.jpg" alt=""><i class="fa fa-link"></i></a>
                                            <figcaption><img src="<?php echo base_url(); ?>assets/extra-images/classic-figcaption-img1.jpg" alt=""></figcaption>
                                        </figure>
                                        <div class="education-blog-classic-text">
                                            <h5><a href="">Variation Of Ordinary Lor</a></h5>
                                            <ul class="education-course-option">
                                                <li><a href="">By John Ryan</a></li>
                                                <li>Aug 21st, 2017</li>
                                            </ul>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipci ng elit. Praesent feugiat urna ipsum maxis malesuada. Donec non ex faucibus,</p>
                                            <a href="" class="education-readmore-btn">Read More <i class="fa fa-long-arrow-right"></i></a>
                                        </div>
                                    </div>
                                    <div class="classic-blog-padding">
                                        <figure><a href=""><img src="<?php echo base_url(); ?>assets/extra-images/classic-blog-img3.jpg" alt=""><i class="fa fa-link"></i></a>
                                            <figcaption><img src="<?php echo base_url(); ?>assets/extra-images/classic-figcaption-img1.jpg" alt=""></figcaption>
                                        </figure>
                                        <div class="education-blog-classic-text">
                                            <h5><a href="">Variation Of Ordinary Lor</a></h5>
                                            <ul class="education-course-option">
                                                <li><a href="">By John Ryan</a></li>
                                                <li>Aug 21st, 2017</li>
                                            </ul>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipci ng elit. Praesent feugiat urna ipsum maxis malesuada. Donec non ex faucibus,</p>
                                            <a href="" class="education-readmore-btn">Read More <i class="fa fa-long-arrow-right"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                      </div>
                </div>
            </div>
            <!--// Main Section \\-->

  

            <!--// Main Section \\-->
            <div class="education-main-section education-partner-full">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="education-fancy-title">
                                <i class="fa fa-graduation-cap"></i>
                                <span>our Best Service</span>
                                <h2>Our Partners</h2>
                            </div>
                            <div class="education-partner">
                                <ul>
                                    <li><a href=""><img src="<?php echo base_url(); ?>assets/extra-images/partner-img-1.jpg" alt=""></a></li>
                                    <li><a href=""><img src="<?php echo base_url(); ?>assets/extra-images/partner-img-2.jpg" alt=""></a></li>
                                    <li><a href=""><img src="<?php echo base_url(); ?>assets/extra-images/partner-img-3.jpg" alt=""></a></li>
                                    <li><a href=""><img src="<?php echo base_url(); ?>assets/extra-images/partner-img-4.jpg" alt=""></a></li>
                                    <li><a href=""><img src="<?php echo base_url(); ?>assets/extra-images/partner-img-3.jpg" alt=""></a></li>
                                    <li><a href=""><img src="<?php echo base_url(); ?>assets/extra-images/partner-img-4.jpg" alt=""></a></li>
                                    <li><a href=""><img src="<?php echo base_url(); ?>assets/extra-images/partner-img-1.jpg" alt=""></a></li>
                                    <li><a href=""><img src="<?php echo base_url(); ?>assets/extra-images/partner-img-2.jpg" alt=""></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--// Main Section \\-->

            <!--// Main Section \\-->
            <div class="education-main-section">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="education-subscribe-newsletter">
                                <img src="extra-images/news-latter-img.jpg" alt="">
                                <div class="education-newslatter-text">
                                    <h2>Subscribe To Our Newsletter</h2>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent feugiat ipsum maximus malesuada. Donec non ex faucibus, fringilla tellus eget, maximus arcu. Duis et eros nisl.</p>
                                    <form>
                                        <input type="text" value="Type Here" onblur="if(this.value == '') { this.value ='Type Here'; }" onfocus="if(this.value =='Type Here') { this.value = ''; }">
                                        <label><input type="submit" value="Subscribe Now"></label>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--// Main Section \\-->

		</div>
		<!--// Main Content \\-->

        <!--// Footer \\-->
        <footer id="education-footer" class="education-footer-one">
            <span class="education-footer-pattren"></span>

            <!--// Footer Widget \\-->
            <div class="education-footer-widget">
                <div class="container">
                    <div class="row">
                        <!--// Widget Contact Info \\-->
                        <aside class="col-md-4 widget widget_contact_info">
                            <a href="index-2.html" class="education-footer-logo"><img src="images/footer-logo.png" alt=""></a>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent feugiat urna non ipsum maxim us malesuada.</p>
                            <ul>
                                <li><i class="education-color fa fa-home"></i> 195 Cooks Mine Road Espa nola, NM 87532</li>
                                <li><i class="education-color fa fa-phone"></i> +123 45 678 - 00 913 2245 <br>678</li>
                                <li><i class="education-color fa fa-envelope"></i> <a href="mailto:name@email.com">info@example.com - </a> <a href="mailto:name@email.com">example@abc.com</a></li>
                            </ul>
                        </aside>
                        <!--// Widget Contact Info \\-->
                        <!--// Widget Featured Courses \\-->
                        <aside class="col-md-4 widget widget_featured_courses">
                            <div class="education-footer-title"> <h4>Featured Courses</h4> </div>
                            <ul>
                                <li>
                                    <figure><a href=""><img src="extra-images/widget-featured-courses-1.jpg" alt=""></a>
                                        <figcaption>
                                            <h6><a href="">Lorem ipsum dolor sit amet, cons scing elit. Praesent.</a></h6>
                                            <div class="star-rating"><span class="star-rating-box" style="width:54%"></span></div>
                                            <small>( 12 Reviews )</small>
                                        </figcaption>
                                    </figure>
                                </li>
                                <li>
                                    <figure><a href=""><img src="extra-images/widget-featured-courses-2.jpg" alt=""></a>
                                        <figcaption>
                                            <h6><a href="">Lorem ipsum dolor sit amet, cons scing elit. Praesent.</a></h6>
                                            <div class="star-rating"><span class="star-rating-box" style="width:34%"></span></div>
                                            <small>( 12 Reviews )</small>
                                        </figcaption>
                                    </figure>
                                </li>
                                <li>
                                    <figure><a href=""><img src="extra-images/widget-featured-courses-3.jpg" alt=""></a>
                                        <figcaption>
                                            <h6><a href="">Lorem ipsum dolor sit amet, cons scing elit. Praesent.</a></h6>
                                            <div class="star-rating"><span class="star-rating-box" style="width:85%"></span></div>
                                            <small>( 12 Reviews )</small>
                                        </figcaption>
                                    </figure>
                                </li>
                            </ul>
                        </aside>
                        <!--// Widget Featured Courses \\-->
                        <!--// Widget Gallery \\-->
                        <aside class="col-md-4 widget widget_gallery">
                            <div class="education-footer-title"> <h4>Flicker Images</h4> </div>
                            <ul>
                                <li><a data-fancybox-group="group" href="extra-images/widget-gallery-1.jpg" class="fancybox"><img src="extra-images/widget-gallery-1.jpg" alt=""></a></li>
                                <li><a data-fancybox-group="group" href="extra-images/widget-gallery-2.jpg" class="fancybox"><img src="extra-images/widget-gallery-2.jpg" alt=""></a></li>
                                <li><a data-fancybox-group="group" href="extra-images/widget-gallery-3.jpg" class="fancybox"><img src="extra-images/widget-gallery-3.jpg" alt=""></a></li>
                                <li><a data-fancybox-group="group" href="extra-images/widget-gallery-4.jpg" class="fancybox"><img src="extra-images/widget-gallery-4.jpg" alt=""></a></li>
                                <li><a data-fancybox-group="group" href="extra-images/widget-gallery-5.jpg" class="fancybox"><img src="extra-images/widget-gallery-5.jpg" alt=""></a></li>
                                <li><a data-fancybox-group="group" href="extra-images/widget-gallery-6.jpg" class="fancybox"><img src="extra-images/widget-gallery-6.jpg" alt=""></a></li>
                                <li><a data-fancybox-group="group" href="extra-images/widget-gallery-7.jpg" class="fancybox"><img src="extra-images/widget-gallery-7.jpg" alt=""></a></li>
                                <li><a data-fancybox-group="group" href="extra-images/widget-gallery-8.jpg" class="fancybox"><img src="extra-images/widget-gallery-8.jpg" alt=""></a></li>
                            </ul>
                        </aside>
                        <!--// Widget Gallery \\-->
                    </div>
                </div>
            </div>
            <!--// Footer Widget \\-->
